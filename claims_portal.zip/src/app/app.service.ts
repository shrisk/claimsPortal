import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from './model/User';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  baseURL: string = "http://localhost:10090";
  user = new BehaviorSubject<User>(new User);

  constructor(private http: HttpClient) {
  }

  register(user: User): Observable<any> {
    return this.http.post(this.baseURL + '/user', user);
  }

  addUserDetails(user: User): Observable<any> {
    return this.http.post(this.baseURL + '/user/update', user);
  }

  getUserById(id: number): Observable<any> {
    return this.http.get(this.baseURL + '/user/' + id);
  }

  getUsers(): Observable<any> {
    return this.http.get(this.baseURL + '/user');
  }

  userLogin(mobileNumber: string, password: string): Observable<any> {
    let params = new HttpParams();
    params = params.append('mobileNumber', mobileNumber);
    params = params.append('password', password);

    return this.http.get(this.baseURL + '/user/login', {params: params});
  }

}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { User } from '../model/User';

@Component({
  selector: 'app-claim',
  templateUrl: './claim.component.html',
  styleUrls: ['./claim.component.css']
})
export class ClaimComponent implements OnInit {

  form: FormGroup = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    fatherName: new FormControl(''),
    email: new FormControl(false),
    gender: new FormControl(''),
    dob: new FormControl(''),
    phone: new FormControl(''),
    aadhar: new FormControl(''),
    address: new FormControl(''),
    state: new FormControl(''),
    country: new FormControl(''),
    accountNum: new FormControl(''),
    ifsc: new FormControl(''),
    branch: new FormControl(''),
    panNum: new FormControl(''),
  });
  
  loading = false;
  submitted = false;
  user: User = new User;
  
  constructor(
    private formBuilder: FormBuilder,
    private route: Router,
    private service: AppService
  ) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      fatherName: ['', Validators.required],
      email: ['', Validators.required],
      gender: ['', Validators.required],
      dob: ['', Validators.required],
      phone: ['', Validators.required],
      aadhar: ['', Validators.required],
      address: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      accountNum: ['', Validators.required],
      ifsc: ['', Validators.required],
      branch: ['', Validators.required],
      panNum: ['', Validators.required],
    });

    this.service.user.subscribe((user) => {
      if (user !== null) {
        this.user = user;
        this.form.get('firstName')?.setValue(user.firstName);
        this.form.get('lastName')?.setValue(user.lastName);
        this.form.get('email')?.setValue(user.emailAddress);
        this.form.get('phone')?.setValue(user.mobileNumber);
      }
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  reset() {
    this.form.reset();
  }

  saveClaim() {
    this.submitted = true;
    if (this.form.valid) {
      this.user.firstName = this.form.get('firstName')?.value;
      this.user.lastName = this.form.get('lastName')?.value;
      this.user.fatherName = this.form.get('fatherName')?.value;
      this.user.emailAddress = this.form.get('email')?.value;
      this.user.gender = this.form.get('gender')?.value;
      this.user.dob = this.form.get('dob')?.value;
      this.user.mobileNumber = this.form.get('phone')?.value;
      this.user.aadharNumber = this.form.get('aadhar')?.value;
      this.user.address = this.form.get('address')?.value;
      this.user.state = this.form.get('state')?.value;
      this.user.country = this.form.get('country')?.value;
      this.user.accountNumber = this.form.get('accountNum')?.value;
      this.user.ifsc = this.form.get('ifsc')?.value;
      this.user.branch = this.form.get('branch')?.value;
      this.user.panNumber = this.form.get('panNum')?.value;

      this.service.addUserDetails(this.user).subscribe((resp) => {
        if (resp !== null) {
          alert("User details saved successfully !!!");
          this.service.user.next(resp);
          this.route.navigate(['/status']);
        } else {
          alert("User details save failed !!!");
        }
      })
    }
  }
    
}

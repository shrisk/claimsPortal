export class User {
    id!: number;
    firstName!: string;
    lastName!: string;
    fatherName!: string;
    gender!: string;
    dob!: Date;
    emailAddress!: string;
    password!: string
    mobileNumber!: number;
    aadharNumber!: number;
    address!: string;
    state!: string;
    country!: string;
    accountNumber!: string;
    ifsc!: string;
    branch!: string;
    panNumber!: string;
    isActive!: boolean;
}
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { User } from '../model/User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form: FormGroup = new FormGroup({
    phone: new FormControl(''),
    password: new FormControl(''),
    reactiveRadio: new FormControl('')
  });

  loading = false;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private route: Router,
    private service: AppService
  ) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      phone: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      reactiveRadio: [true, Validators.required]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  login() {
    if (this.form.valid) {
      let phone = this.form.get('phone')?.value;
      let password = this.form.get('password')?.value;
      let reactiveRadio = this.form.get('reactiveRadio')?.value;

      this.service.userLogin(phone, password).subscribe((res) => {
        if (res !== null) {
          alert("User logged in successfully !!!");
          this.service.user.next(res);
          if (!reactiveRadio) {
            this.route.navigate(['/status']);
          } else {
            this.service.user.next(new User);
            this.route.navigate(['/claim']);
          }
        } else {
          alert("Invalid phone number or password !!!");
        }
      });
    }
  }
}

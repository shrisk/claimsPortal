import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { User } from '../model/User';
import Validation from '../utils/validation';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  form: FormGroup = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    password: new FormControl(''),
    confirmPassword: new FormControl(''),
    email: new FormControl(false),
    phone: new FormControl(''),
  });
  
  loading = false;
  submitted = false;
  user: User = new User;

  constructor(
    private formBuilder: FormBuilder,
    private route: Router,
    private service: AppService
  ) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', Validators.required],
      phone: ['', Validators.required]
    },
    {
      validators: [Validation.match('password', 'confirmPassword')]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  reset() {
    this.form.reset();
  }

  register() {
    this.submitted = true;
    if (this.form.valid) {
      this.user.firstName = this.form.get('firstName')?.value;
      this.user.lastName = this.form.get('lastName')?.value;
      this.user.emailAddress = this.form.get('email')?.value;
      this.user.mobileNumber = this.form.get('phone')?.value;
      this.user.password = this.form.get('password')?.value;

      this.service.register(this.user).subscribe((resp) => {
        if (resp !== null) {
          alert("User registered successfully !!!");
          this.service.user.next(resp);
          this.route.navigate(['/claim']);
        } else {
          alert("User registration failed !!!");
        }
      })
    }
  }
    
}
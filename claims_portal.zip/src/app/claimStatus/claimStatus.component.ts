import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { User } from '../model/User';

@Component({
  selector: 'app-claim-status',
  templateUrl: './claimStatus.component.html',
  styleUrls: ['./claimStatus.component.css']
})
export class ClaimStatusComponent implements OnInit {

  user: User = new User;

  constructor(
    private service: AppService
  ) { }

  ngOnInit() {
    this.service.user.subscribe((user) => {
      if (user !== null) {
        this.user = user;
      }
    });
  }
    
}

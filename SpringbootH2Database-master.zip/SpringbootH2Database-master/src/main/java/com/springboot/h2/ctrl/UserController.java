package com.springboot.h2.ctrl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.h2.model.User;
import com.springboot.h2.serv.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	private final Logger log = LoggerFactory.getLogger(this.getClass()); 

	@Autowired
	UserService service;

	@PostMapping
	public User saveUser(final @RequestBody User user) {
		log.info("Saving user details in the database.");
		user.setActive(false);
		User resp = service.save(user);
		return resp;
	}

	@PostMapping(value= "/update")
	public User updateUser(final @RequestBody User user) {
		log.info("Update user details in the database.");
		User resp = service.save(user);
		return resp;
	}

	@GetMapping
	public List<User> getUsers() {
		log.info("Getting student details from the database.");
		return service.getUser();
	}

	@GetMapping(value= "/{id}")
	public User getUserById(@PathVariable("id") int id) {
		log.info("Getting student details from the database.");
		return service.getUserById(id);
	}

	@GetMapping(value= "/login")
	public User userLogin(@RequestParam("phoneNumber") String phoneNumber, 
						  @RequestParam("password") String password) {
		log.info("Getting User details from the database.");
		return service.userLogin(phoneNumber, password);
	}
}

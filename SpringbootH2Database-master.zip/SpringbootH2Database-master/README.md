# SpringbootH2Database

clone this repo
excecute the below command:

mvn clean install

once the build is success

mvn spring-boot:run
